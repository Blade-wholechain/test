// Function to load the HelpScout Beacon script dynamically
function loadHelpScout() {
    (function(e, t, n) {
        function a() {
            var e = t.getElementsByTagName("script")[0],
                n = t.createElement("script");
            n.type = "text/javascript";
            n.async = true;
            n.src = "https://beacon-v2.helpscout.net";
            e.parentNode.insertBefore(n, e);
        }
        if (e.Beacon = n = function(t, n, a) {
            e.Beacon.readyQueue.push({ method: t, options: n, data: a });
        }, n.readyQueue = [], "complete" === t.readyState) return a();
        e.attachEvent ? e.attachEvent("onload", a) : e.addEventListener("load", a, false);
    })(window, document, window.Beacon || function() {});
}

// Initialize the HelpScout Beacon with custom options
function initializeHelpScout() {
    window.Beacon('init', '3a26faad-62a9-49e7-af61-e791de4d22c0');
}

// Reposition the HelpScout Beacon to the bottom right
function repositionHelpScout() {
    const beaconButton = document.querySelector(".hsds-beacon .fDPBpL");
    if (beaconButton) {
        beaconButton.style.position = "fixed";
        beaconButton.style.bottom = "20px";
        beaconButton.style.right = "20px";
        beaconButton.style.left = "auto";
        beaconButton.style.transform = "none";
        console.log("HelpScout Beacon repositioned to bottom-right.");
    } else {
        console.warn("HelpScout Beacon button not found. Retrying...");
        setTimeout(repositionHelpScout, 500); // Retry after a short delay if the button isn't found yet
    }
}

// Override the "Help" link to open the HelpScout Beacon
function setupHelpLink() {
    // Target the Help link that points to `#` using its exact `href`
    const helpLink = document.querySelector("nav a[href='http://127.0.0.1:8000/#']");
    if (helpLink) {
        helpLink.addEventListener("click", function(event) {
            event.preventDefault();  // Prevent default link behavior
            window.Beacon('open');   // Open the HelpScout Beacon
            console.log("HelpScout Beacon opened from Help menu.");
        });
    } else {
        console.warn("Help link with href='#' not found in the menu. Retrying...");
        setTimeout(setupHelpLink, 500);  // Retry after a short delay if the link isn't found yet
    }
}

// Function to ensure HelpScout is ready before repositioning and adding event listeners
function onBeaconReady() {
    console.log("Initializing and repositioning HelpScout Beacon...");
    initializeHelpScout();
    window.Beacon('on', 'ready', repositionHelpScout);
    // setupHelpLink();  // Set up the Help link click event to open the Beacon
}

// Wait until the entire page is loaded before running the script
window.addEventListener('load', () => {
    loadHelpScout();
    onBeaconReady();
});