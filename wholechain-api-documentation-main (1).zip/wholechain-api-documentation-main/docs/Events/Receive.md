## Introduction
Receive events represent when you confirm a product's arrival at your own internal location. Receive events normally follow Ship events, though you can log a Receive event from a non-Wholechain user, thereby starting the traceability journey in Wholechain at this point. If the user receiving product notices any discrepancies between the ship record and the physical product received, they also have the option to reject the record, which sends a notification to the shipper that some information was off and the event needs to be revised. 
## How it works: 
- Scenario 1: A user goes to their Shipping / Receiving page and clicks on the Pending tab. The user selects items that they wish to receive, and confirms it to a specific internal location.
- Scenario 2: A user goes to the Shipping / Receiving page or any product's Current Inventory page and clicks Actions > Receive. This prompts them to select from whom the product came as well as the item details they are receiving. This scenario occurs when the goods come from a user who is not yet on Wholechain, or who did not use Wholechain to log a ship event.   
- In Scenario 1 above, the recipient also has the option to reject the items in their Pending tab if the Ship event record appears inaccurate. 
- Scenario 3: This action can be performed through the API

![Local image](Images/ReceiveImages/Receive_Image1.png)
## Practical Examples
- A distributor confirms receipt of the product and records shipped to them from a supplier. 
- A grocery store confirms receipt of a shipment of fresh produce from a local farm, logging the arrival of the vegetables into their Wholechain system.
## Request Body
## Example Responses
