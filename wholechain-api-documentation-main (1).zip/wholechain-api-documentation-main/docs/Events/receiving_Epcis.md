## Receiving an EPCIS shipment from a Non-Wholechain EPCIS Platforms

If you have a trade partner that is not a Wholechain user but uses another EPCIS-compliant system and they want to send you an EPCIS shipment, follow the steps below to set up the connection. This will allow you to exchange shipment data in EPCIS format.

## Adding a Non-Wholechain Trade Partner

1.	Navigate to the Networks Tab:
    - Go to the Networks tab on the Wholechain platform.
2.	Add the Trade Partner:
    - Click the Actions button and select Add Company/Location.
3.	Enter the Company Information:
    - You will be asked to provide a company name.
    - Enter the company name and proceed.
4.	Specify the External Traceability System:
    - Toggle on the switch labeled “This company uses another traceability system”.
    - This indicates that the company uses an external EPCIS-compliant traceability platform.
6.	Locate Your Company’s Digital Link URL:
    - You will see your company’s name listed along with your Digital Link URL at the bottom of the page.
    ![Local image](Images/EPCIS/Receiving_EPCIS.png)
7.	Generate and Share the API Key:
    - Click the Generate API Key button next to your company’s profile.
    - Share the generated API key and your Digital Link URL with your trade partner.
8. Once the trade partner has been added, confirm the setup and save the configuration.

**Now your partners can send you EPCIS-compliant data through their EPCIS-compliant system provider.**