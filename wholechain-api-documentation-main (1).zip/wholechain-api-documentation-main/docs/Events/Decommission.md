
## Introduction
A Decommission event represents when a product exits the traced supply chain. A common example of a decommission instance is when a product is consumed (i.e. a customer purchases the product from a store). Another example would be if a product is damaged, destroyed, or for some reason needs to be removed from circulation.
## How it works: 
- A Wholechain user selects the item they wish to decommission, and is prompted to provide a reason for decommissioning.
- The Decommission event record is written onto the blockchain to show the ending point of every traced supply chain.
## Practical Examples
- A shipment of apples is decommissioned after a portion of the crates is found to be damaged during transit and is deemed unfit for sale.
- A product is purchased by a customer at a retail store..
## Request Body
## Example Responses



