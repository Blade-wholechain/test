## Sending an EPCIS shipment from a Non-Wholechain EPCIS Platforms
If you have a trade partner that is not a Wholechain user but uses another EPCIS-compliant system and wants to exchange EPCIS shipment data with you, follow the steps below to set up the connection:

## Adding a Non-Wholechain Trade Partner

1.	Navigate to the Networks Tab:
	- Go to the Networks tab on the Wholechain platform.
2.	Add the Trade Partner:
	- Click the Actions button and select Add Company/Location.
3.	Enter Company Information:
	- Provide the name of the company and proceed.
4.	Specify the External Traceability System:
	- Toggle the switch labeled “This company uses another traceability system”.
	- This indicates that the company uses an external EPCIS-compliant traceability platform.
5.	Add the Trade Partner’s Digital Link URL:
	- Locate the Digital Link URL field and enter the digital link URL of your trade partner’s traceability system.
	- You may need to request this URL from your trade partner.
![Local image](Images/EPCIS/Shipping_EPCIS.png)
6.	Enter the Trade Partner’s API Key:
	- Enter the API key associated with the trade partner’s traceability system in the API Key field.
	- You may need to request this URL from your trade partner.
	- This will enable you to exchange EPCIS data with this partner.
7.	Save the Configuration:
	- Confirm and save the trade partner information to complete the setup.

**You are now able to send shipments to your partners using EPCIS Compliant Systems.**





