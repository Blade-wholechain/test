## Introduction
A Commission event represents a product coming into existence in its documented supply chain. It typically occurs at the farthest upstream point of the traceability journey - either the point of harvest, or the first time that a product is being documented as itself.
## How it works: 
- A Wholechain user can initiate a Commission event directly from the product’s current inventory page or via the Wholechain API, with the flexibility to incorporate custom data as needed. 
- The record of the commissioned product is stored in the Wholechain database and written to the blockchain, establishing the origin point of the product within the supply chain.
## Practical Examples
- A shipment of apples is decommissioned after a portion of the crates is found to be damaged during transit and is deemed unfit for sale.
- A product is purchased by a customer at a retail store.
## Request Body
## Example Responses
