## Introduction
A Transform event describes an activity that irreversibly changes a product, transforming it into a new, traceable output product with a new Primary ID (i.e. a new serial number or lot number). It could be that raw materials are combined, cut or melted to make a new product, or that a product is packaged for consumption.  
## How it works
- A Wholechain user selects the input item(s) they want to transform from their current inventory, and is prompted to specify details about the output product. 
- The user can enter the output product details manually or via CSV upload for multiple items. 
- The new product appears in the Current Inventory of that product page. 
Users can also use the "+ product" tab in the event drawer to transform multiple inputs into multiple output products. 
- This event can also be performed through the API
![Local image](Images/TransformImages/Transform_Image1.png)
![Local image](Images/TransformImages/Transform_Image2.png)
![Local image](Images/TransformImages/Transform_Image3.png)
## Practical Examples
- At a seafood processor, an input lot of whole sockeye salmon is processed into three distinct production lots of packaged sockeye salmon fillets.
- Traceable harvests from multiple fishing vessels are irreversibly combined into one container of whole sockeye salmon upon landing.
- At a pasta factory, workers mix flour, egg and water input products to create 4 differently-shaped pasta output products. 
## Request Body
## Example Responses