## Introduction
External Ship events represent when product is shipped from one Company to another. Logging a Ship event moves product item(s) from a company's current inventory to its shipped inventory tab with the status "pending", until the recipient company either receives or rejects the item(s) in their account. 
## How it works:
- **Option 1:** a Wholechain user selects an item from their current inventory, and selects the recipient company + location as well as dispatch date. 
- **Option 2:** a Wholechain user creates a Batch Ship event from the Shipping / Receiving page, where they can send multiple products and items at once. 
- **Option 3:** The user can perform this action through the API
![Local image](Images/ShipExternalImages/Ship_External_Image1.png)
## Practical Examples
- A shrimp processor ships 3 pallets of shrimp to a distributor’s warehouse.
- A winery ships 500 bottles of wine to a retailer's distribution center. 
## Request Body
## Example Responses