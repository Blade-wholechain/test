## Introduction
An Internal Ship event represents product movement internally within a company's various business locations, or partner facilities while the company maintains custody. Products maintain their physical properties, they simply move from one location to another. 
## How it works:
- A Wholechain user selects the item(s) they wish to ship, and selects the ship date(s). 
- The user selects themselves in the Recipient field, as well as the location the goods are shipping to. This location would have already been set up in the user's business settings. 
- The user can select to automatically log the Receive event, and will be prompted to enter the date the items were received. 
- The user can perform this action through the API
![Local image](Images/ShipInternalImages/Ship_Internal_image1.png)
## Practical Examples
- A batch of coffee beans is shipped from a company's roasting facility to its packaging facility. Both facilities are owned and operated by the same company, ensuring the beans maintain their traceability within the internal supply chain.
- A product moves from a cold storage facility in one location to a processing facility in another location, both of which are owned and managed by the same company. 
## Request Body
## Example Responses