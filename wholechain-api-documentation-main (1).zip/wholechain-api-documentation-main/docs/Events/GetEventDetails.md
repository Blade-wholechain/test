## Endpoint
```
GET https://connect.wholechain.com/epcis/Events/details
```
## Overview

The EPCIS Event Details API allows users to query event information associated with a specific lot or purchase order. Users can view event details related to commissioning, observing, transformation, shipping, and receiving activities within their company. After an external shipment event or a transform event, the user can no longer access event data related to the lot, unless they use the new lot number assigned after a transformation event.

## This API supports querying based on:

	•	Lot Serial Number
	•	Purchase Order Number

## Limitations

- A user can see all event details for a given lot that took place within their company up to and including an external shipment or a transformation event.
- Once an external shipment leaves the company, the user cannot access event details for that lot beyond the external shipment.
- When a transform event occurs, the lot number changes. The new lot number must be used for future queries, but the user will only see events after the transformation.

## Authentication

The API uses an API key (X-API-KEY) to authenticate requests. Each user has a unique API key that controls access to event details tied to their company. To understand where this can be found, please visit the [Authentication](http://127.0.0.1:8000/GettingStarted/Authentication/) page.

## Request Parameters

| Parameter        | Type    | Required | Description                                                  |
|------------------|---------|----------|--------------------------------------------------------------|
| `LotSerial`      | String  | Yes      | The serial number of the lot to query.                       |
| `PurchaseOrder`  | String  | No       | The purchase order number to filter the results.             |
| `PageNumber`     | Integer | No       | The page number for paginated results.                       |
| `PageSize`       | Integer | No       | The number of results to return per page.                    |
| `SortBy`         | String  | No       | The sorting criteria for the results (e.g., eventDate).      |

## Request Headers

| Header            | Type    | Required | Description                                                  |
|-------------------|---------|----------|--------------------------------------------------------------|
| `accept`          | String  | Yes      | Specifies the response format (e.g., `text/plain`).           |
| `X-API-KEY`       | String  | Yes      | The user's API key used for authentication.                  |

## Example Requests
=== "Python"
    ```py
    import requests

    url = 'https://connect.wholechain.com/epcis/Events/details'
    headers = {
        'accept': 'text/plain',
        'X-API-KEY': 'XXXX'
    }
    params = {
        'LotSerial': '1357',
        'PurchaseOrder': '',
        'PageNumber': '',
        'PageSize': '',
        'SortBy': ''
    }

    response = requests.get(url, headers=headers, params=params)

    # Print response status code and text
    print(response.status_code)
    print(response.text)
    ```

=== "C#"

    ``` C#
    using System;
    using System.Net.Http;
    using System.Threading.Tasks;

    class Program
    {
        private static readonly HttpClient client = new HttpClient();

        static async Task Main()
        {
            var url = "https://connect.wholechain.com/epcis/Events/details";
            var apiKey = "XXXX";

            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("accept", "text/plain");
            request.Headers.Add("X-API-KEY", apiKey);

            var queryParams = new System.Collections.Generic.Dictionary<string, string>
            {
                { "LotSerial", "1357" },
                { "PurchaseOrder", "" },
                { "PageNumber", "" },
                { "PageSize", "" },
                { "SortBy", "" }
            };

            var query = new System.UriBuilder(url);
            var queryString = System.Web.HttpUtility.ParseQueryString(query.Query);
            foreach (var param in queryParams)
            {
                queryString[param.Key] = param.Value;
            }
            query.Query = queryString.ToString();
            request.RequestUri = query.Uri;

            var response = await client.SendAsync(request);

            Console.WriteLine((int)response.StatusCode);
            var responseText = await response.Content.ReadAsStringAsync();
            Console.WriteLine(responseText);
        }
    }
    ```

=== "Curl"

    ``` sh
    curl -X GET "https://connect.wholechain.com/epcis/Events/details" \
    -H "accept: text/plain" \
    -H "X-API-KEY: XXXX " \
    --data-urlencode "LotSerial=1357" \
    --data-urlencode "PurchaseOrder=" \
    --data-urlencode "PageNumber=" \
    --data-urlencode "PageSize=" \
    --data-urlencode "SortBy="
    ```



## Example Response 
```
{
  "totalPages": 1,
  "pageNumber": 1,
  "pageSize": 20,
  "totalItems": 4,
  "results": [
    {
      "id": "0408989b-dc15-4bef-ab85-6591acef657e",
      "eventId": "562feb29-4cf8-4f5a-99c4-00028e89d35f",
      "eventType": "Ship",
      "productName": "Hake",
      "lotSerial": "1357",
      "quantity": 1000,
      "locationName": "Front Loading Dock",
      "companyName": "Oceana Group Ltd",
      "eventDate": "2024-09-25T15:35:52+00:00"
    },
    {
      "id": "0e6a9845-396c-4d1b-a570-b91b11548359",
      "eventId": "3d1d0d0a-2ba5-4846-adef-4551227ca993",
      "eventType": "Commission",
      "productName": "Hake",
      "lotSerial": "1357",
      "quantity": 1000,
      "locationName": "Oceana House",
      "companyName": "Oceana Group Ltd",
      "eventDate": "2024-09-25T15:34:38+00:00"
    }
  ]
}
```

## Errors
- 500: Internal Server Error