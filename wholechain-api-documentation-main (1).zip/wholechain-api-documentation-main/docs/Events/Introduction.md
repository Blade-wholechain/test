## What is event-based traceability?

Wholechain is designed to help businesses achieve end-to-end supply chain traceability, which is defined by the United Nations Global Compact and Business (UNGC) and Business for Social Responsibility (BSR) as: 

>"The ability to identify and trace the history, distribution, location and application of products, parts and materials, to ensure the reliability of sustainability claims, in the areas of human rights, labor (including health and safety), the environment and anti-corruption."

Wholechain tackles traceability by breaking up complex supply chain webs into a series of steps - which we call events. Events capture the who, what, when and where of each activity a product undergoes in its journey to consumers, in addition to customizable data unique to each supply chain. We’ve strategically aligned our event types with GS1’s Electronic Product Code Information Services (EPCIS) standards to make sure data is compatible with the global trade ecosystem businesses are already working within. 

The combination of blockchain-based data collection, simple desktop and mobile app user experiences, and robust storytelling with Sourceview, means more trust and accountability between stakeholders within the supply chain as well as with consumers. 

 