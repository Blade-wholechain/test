## What is EPCIS?

EPCIS (Electronic Product Code Information Services) is a global GS1 standard designed to enable the exchange of event data related to the movement and status of products throughout the supply chain. It provides a standardized framework for capturing, sharing, and querying data about physical objects at key points in the supply chain, making it a critical tool for ensuring traceability, transparency, and visibility across industries.

EPCIS event data typically includes information about:

- **What:** The objects involved in the event (e.g., product IDs, lot numbers).
- **When:** The time the event occurred.
- **Where:** The location where the event happened (e.g., shipment, receipt location).
- **Why:** The business context of the event (e.g., a shipping or receiving activity).

By capturing this data in a consistent format, EPCIS helps companies share information with their partners, ensuring interoperability across different systems and enhancing supply chain visibility.
## Use Case Example:
When a product is shipped from one company to another, the shipping company can generate an EPCIS event that details the product being shipped, the time and location of shipment, and the reason (e.g., shipping to a customer). The receiving company can then use this data to track when and where the product was shipped and to correlate it with their receiving events.

