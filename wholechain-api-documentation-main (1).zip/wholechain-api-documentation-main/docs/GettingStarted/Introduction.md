
## Introduction to the Wholechain API
Welcome to the Wholechain API documentation! Our API provides seamless access to the comprehensive traceability features of Wholechain, a leading global platform designed to foster transparency, accountability, and compliance across the supply chain. Built with global standards in mind, Wholechain is GDST capable and EPCIS compliant, ensuring your supply chain data is handled in accordance with the latest traceability frameworks.

Whether you are looking to improve product visibility, optimize data flow, or enhance overall supply chain efficiency, the Wholechain API empowers you with the tools to seamlessly integrate our traceability solutions into your existing systems. This documentation will guide you through our API endpoints, request structures, and best practices for leveraging Wholechain’s powerful features in your operations.
## Interacting with the Whole Chain API

The Whole Chain API offers a set of endpoints that allow users to interact with their supply chain data in a flexible and scalable way. By using this API, users can perform key actions related to supply chain events, such as querying and recording data based on various business processes. The API is built to support ongoing expansion and can accommodate additional functionalities as new features and capabilities are introduced.

## API Endpoints

- **GET Requests:** Used to retrieve data from the system, such as event details associated with specific lot numbers or purchase orders. The responses are tailored based on the user’s access rights and the data provided.
- **POST Requests:** Used to submit data, such as creating new events in the system. The API accepts structured data in JSON format to log important details related to supply chain events.



