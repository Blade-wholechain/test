## Understanding HTTP Status Codes in Wholechain

When interacting with the Wholechain API, you may encounter a few specific HTTP status codes that provide important feedback on your requests. Here’s an explanation of the ones you are most likely to see:

### 200 OK: Success

- Description: This status code indicates that your request was successfully processed by the server. The server has understood and fulfilled the request, and the response contains the requested data or confirmation of a completed action.
- When to Expect: You’ll receive this when your API call is valid and correctly formatted.

### 400 Bad Request: Client Error

- Description: This indicates that there is an issue with the request sent by the client (your system). The server could not understand the request due to invalid syntax or missing required information.
- When to Expect: You might receive this status code if your API request is incorrectly formatted, missing necessary fields, or contains invalid data.

### 500 Internal Server Error: Server Error

- Description: This code signals that the server encountered an error or unexpected condition that prevented it from processing the request. This is usually due to a problem on the server’s side, not an issue with your request.
- When to Expect: You’ll receive this when the server is facing technical issues or is unable to fulfill the request for some reason. Typically, these issues are temporary.

### Summary

- 200 OK: The request was successful, and the server processed it correctly.
- 400 Bad Request: There’s an error in your request. Double-check the syntax and required fields.
- 500 Internal Server Error: Something went wrong on the server’s side. Try your request again later.