## What is a sandbox environment?
A sandbox environment is a dedicated space for developers to safely test and experiment with the Wholechain API without affecting the live system or real data. It acts as an isolated environment where you can make API requests, run test scenarios, and experiment with new features or configurations, mimicking the production environment as closely as possible.

## How to Use the Sandbox with the Wholechain API:

1.	**Testing New Integrations:** Before you integrate the Wholechain API into your live system, you can use the sandbox to simulate various use cases, ensuring that your requests, responses, and data flows are functioning as expected.
2.	**Experimenting with API Features:** Use the sandbox to explore different endpoints, test query parameters, and see how the API handles various inputs without any risk to production data.
3.	**Safe Error Handling:** If you’re testing error scenarios or want to push the API to its limits, the sandbox allows you to do so without any adverse effects on your live application.
4.	**Development and Debugging:** During the development phase, the sandbox can be used to repeatedly test code, troubleshoot issues, and refine API requests before moving to the production environment.

## Benefits of the Sandbox Environment:

1. **Zero Impact on Production:** Anything you test or execute in the sandbox stays within the sandbox, ensuring no unintended changes or data corruption occur in your live system.
2. **Realistic Testing:** It replicates the production environment, so you can confidently test with realistic data and conditions.
3. **Safe Experimentation:** Whether you’re trying out a new feature or debugging an issue, the sandbox offers a secure space to experiment.

## How to set up your Wholechain sandbox account
1.	Navigate to [https://sandbox.wholechain.com](https://sandbox.wholechain.com)
2.	Log in using your existing Wholechain credentials from your main account.
3.	Click “Log In.”
4.	You’ll be prompted to provide the following details:
    - Company Name
	- Company Address
	- Time Zone
	- Phone Number
	- Coordinates
5.	Click “Create Account.”
6.	Your sandbox account is now activated.

Once your account is activated, you can start using the sandbox just as you would your main Wholechain application. If you need to test API calls, we recommend using your sandbox API key. To understand where this can be found, please visit the [Authentication](http://127.0.0.1:8000/GettingStarted/Authentication/) page.

By using the Wholechain sandbox, you can confidently develop, test, and optimize your API integrations, ensuring a seamless transition to production.