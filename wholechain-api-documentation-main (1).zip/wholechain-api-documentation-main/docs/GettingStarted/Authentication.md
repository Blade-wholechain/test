
Authentication is essential to ensure that only authorized users can access and interact with the Whole Chain API. It provides a secure way to identify who is making requests and ensures that each user has access only to the data relevant to their account. The Whole Chain API uses API keys as the primary method of authentication.

## What is an API Key?

An API key is a unique string of characters that acts as a secure token, identifying the user making the request. Every request to the Whole Chain API must include this key to verify the identity of the user and authorize access to the API’s functionalities.

## How to Access Your API Key

To access your API key, follow these steps:

1. **Log into Your Whole Chain Account:** Use your credentials to log into your Whole Chain platform account.
2. **Navigate to Settings:** Once logged in, go to the settings section by clicking on the **settings icon** located in the top right corner of the dashboard.
3. **Account Settings:** On the left-hand side panel, select **Account Settings**.
4. **Scroll Down to Integration Settings:** In the Account Settings page, scroll to the bottom until you reach the section labeled **Integration Settings**.
5. **Generate Your API Key:** Under **Integration Settings**, you will see an option labeled **API Key**. Click the **Generate API Key** button. This will generate a new API key for your account.
6. **Use Your API Key:** Once the key is generated, you can copy it and use it in the headers of your API requests.

![Local image](images/API_KEY.png)
## **Important**
It’s important to keep your API key secret at all times. If you believe your API key has been shared or exposed in any way, you should immediately generate a new API key by following the steps outlined above. This will help ensure the security of your account and data.

